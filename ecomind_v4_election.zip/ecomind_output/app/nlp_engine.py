"""
nlp_engine.py
-------------
NLP Analysis Engine — BERT (HuggingFace) + PMI + NRC Emotion + URL Scraper
"""

from __future__ import annotations
import logging, re, math
from pathlib import Path
import pandas as pd
import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ── Lazy BERT loader ──────────────────────────────────────────────────────
_pipeline = None

def _get_pipeline():
    global _pipeline
    if _pipeline is None:
        try:
            from transformers import pipeline
            logger.info("Loading HuggingFace BERT model…")
            _pipeline = pipeline(
                "sentiment-analysis",
                model="distilbert-base-uncased-finetuned-sst-2-english",
                truncation=True, max_length=512,
            )
            logger.info("BERT model ready.")
        except Exception as e:
            logger.warning("BERT unavailable (%s). Using PMI fallback.", e)
    return _pipeline


# ── Aspect keywords ───────────────────────────────────────────────────────
ASPECTS = {
    "Climate Change":   ["climate","global warming","greenhouse","carbon","ipcc","temperature","arctic","co2","methane","warming"],
    "Air Quality":      ["air quality","smog","pollution","emission","exhaust","particulate","pm2","haze","nitrogen"],
    "Plastic & Waste":  ["plastic","waste","recycl","litter","garbage","microplastic","landfill","single-use"],
    "Renewable Energy": ["renewable","solar","wind","green energy","electric","battery","hydro","clean energy","turbine"],
    "Biodiversity":     ["biodiversity","wildlife","species","forest","ecosystem","coral","deforestation","habitat","extinction"],
    "Sustainability":   ["sustainable","sustainab","eco","zero waste","organic","conservation","environment","circular","green"],
}

# ── Emotion keywords ──────────────────────────────────────────────────────
EMOTIONS = {
    "Fear":        ["alarming","terrifying","dangerous","catastrophe","collapse","extinction","devastating","threat","crisis","panic","melt","wildfire","flood","drought"],
    "Anger":       ["outrage","angry","disgusted","unacceptable","shame","blame","hypocrite","irresponsible","ignorant","scandal","corrupt","inaction","failed"],
    "Hope":        ["hope","better","solution","progress","action","change","future","renewable","clean","protect","improve","win","success","positive","recover","restore"],
    "Trust":       ["evidence","data","science","study","report","research","fact","proven","confirm","analysis","scientist","expert","agree"],
    "Sadness":     ["sad","tragedy","loss","extinction","dying","dead","mourn","grief","heartbroken","unfortunate","devastating","terrible","lament"],
    "Anticipation":["expect","soon","predict","forecast","upcoming","warning","watch","monitor","trend","likely","project","anticipate","await"],
    "Surprise":    ["shocking","unexpected","unbelievable","incredible","wow","astonishing","suddenly","unprecedented","never before"],
    "Disgust":     ["disgusting","horrible","revolting","appalling","nauseating","abhorrent","filthy","repulsive"],
}

PMI_POS = ["good","great","positive","better","improve","benefit","success","clean","hope","solution","progress","healthy"]
PMI_NEG = ["bad","terrible","negative","worse","damage","crisis","toxic","danger","threat","harm","pollut","destroy"]

STOP_WORDS = {"a","an","the","is","are","was","were","be","been","have","has","had","do","does","did","will","would","could","should","to","of","in","for","on","with","at","by","from","as","and","but","or","not","this","that","these","those","i","me","my","we","you","it","he","she","they","so","than","too","very","just","now"}


class TextPreprocessor:
    def clean(self, text: str) -> str:
        t = str(text).lower()
        t = re.sub(r"http\S+|www\S+","",t)
        t = re.sub(r"@\w+","",t)
        t = re.sub(r"#(\w+)",r"\1",t)
        t = re.sub(r"[^a-z0-9\s]"," ",t)
        return re.sub(r"\s+"," ",t).strip()

    def tokenize(self, text: str) -> list[str]:
        return [t for t in self.clean(text).split() if t not in STOP_WORDS and len(t) > 1]


class PMIScorer:
    def __init__(self):
        self.prep = TextPreprocessor()

    def score(self, text: str) -> dict:
        tokens = self.prep.tokenize(text)
        n      = max(len(tokens), 1)
        pos_s  = sum(tokens.count(a)/n for a in PMI_POS if a in tokens)
        neg_s  = sum(tokens.count(a)/n for a in PMI_NEG if a in tokens)
        raw    = (pos_s - neg_s) / (pos_s + neg_s + 1e-9)
        raw    = max(-1.0, min(1.0, raw))
        sent   = "positive" if raw > 0.05 else "negative" if raw < -0.05 else "neutral"
        return {"pmi_score": round(raw, 4), "sentiment": sent}


class EmotionDetector:
    def __init__(self):
        self.prep = TextPreprocessor()

    def detect(self, text: str) -> dict:
        cleaned = self.prep.clean(text)
        scores  = {emo: sum(1 for kw in kws if kw in cleaned) for emo, kws in EMOTIONS.items()}
        dominant = max(scores, key=scores.get) if max(scores.values()) > 0 else "Neutral"
        return {"dominant_emotion": dominant, "scores": scores}


def _detect_aspect(text: str) -> str:
    t = str(text).lower()
    for asp, kws in ASPECTS.items():
        if any(kw in t for kw in kws):
            return asp
    return "General Environment"


class BERTAnalyser:
    def __init__(self):
        self.pmi  = PMIScorer()
        self.emo  = EmotionDetector()
        self.prep = TextPreprocessor()
        self._m   = None

    def _load(self):
        if self._m is None:
            self._m = _get_pipeline()

    def analyse(self, text: str) -> dict:
        self._load()
        cleaned = self.prep.clean(text)
        asp     = _detect_aspect(text)
        emo_res = self.emo.detect(text)
        pmi_res = self.pmi.score(text)

        if self._m:
            try:
                out    = self._m(cleaned[:512])[0]
                label  = out["label"].lower()
                score  = float(out["score"])
                sentiment = label if score > 0.6 else "neutral"
                return {
                    "text": text[:200], "sentiment": sentiment,
                    "bert_label": label.upper(), "bert_score": round(score,4),
                    "pmi_score": pmi_res["pmi_score"],
                    "aspect": asp, "emotion": emo_res["dominant_emotion"],
                    "emotion_scores": emo_res["scores"], "model": "distilbert-sst2",
                }
            except Exception as e:
                logger.warning("BERT inference error: %s", e)

        return {
            "text": text[:200], "sentiment": pmi_res["sentiment"],
            "bert_label": pmi_res["sentiment"].upper(), "bert_score": abs(pmi_res["pmi_score"]),
            "pmi_score": pmi_res["pmi_score"],
            "aspect": asp, "emotion": emo_res["dominant_emotion"],
            "emotion_scores": emo_res["scores"], "model": "pmi-fallback",
        }

    def analyse_batch(self, texts: list[str]) -> list[dict]:
        return [self.analyse(t) for t in texts]


class URLScraper:
    HEADERS = {"User-Agent": "Mozilla/5.0 (EcoMindBot/1.0)"}

    def fetch(self, url: str) -> dict:
        try:
            if not url.startswith(("http://","https://")):
                url = "https://" + url
            r = requests.get(url, headers=self.HEADERS, timeout=10)
            r.raise_for_status()
            soup  = BeautifulSoup(r.text, "html.parser")
            title = soup.title.string.strip() if soup.title else "No title"
            for tag in soup(["script","style","nav","footer","header"]):
                tag.decompose()
            text = " ".join(p.get_text(" ", strip=True) for p in soup.find_all("p"))
            text = re.sub(r"\s+"," ",text).strip()
            return {"url":url,"title":title,"text":text[:5000],"word_count":len(text.split()),"error":None}
        except Exception as e:
            return {"url":url,"title":"","text":"","word_count":0,"error":str(e)}


class BatchAnalyser:
    TEXT_COLS = ["text","comment","caption","tweet","post","content","message","body"]

    def __init__(self):
        self.bert = BERTAnalyser()

    def _find_col(self, df: pd.DataFrame) -> str:
        for c in df.columns:
            if c.lower() in self.TEXT_COLS:
                return c
        for c in df.columns:
            if df[c].dtype == object:
                return c
        raise ValueError("No text column found in CSV.")

    def run(self, df: pd.DataFrame, max_rows: int = 500) -> dict:
        df      = df.head(max_rows).copy()
        tc      = self._find_col(df)
        texts   = df[tc].fillna("").astype(str).tolist()
        results = self.bert.analyse_batch(texts)

        df["sentiment"] = [r["sentiment"]  for r in results]
        df["aspect"]    = [r["aspect"]     for r in results]
        df["emotion"]   = [r["emotion"]    for r in results]
        df["pmi_score"] = [r["pmi_score"]  for r in results]
        df["bert_score"]= [r["bert_score"] for r in results]

        absa: dict[str, dict] = {}
        for asp in set(df["aspect"]):
            sub = df[df["aspect"] == asp]
            absa[asp] = {
                "positive": int((sub["sentiment"]=="positive").sum()),
                "negative": int((sub["sentiment"]=="negative").sum()),
                "neutral":  int((sub["sentiment"]=="neutral").sum()),
                "total":    len(sub),
                "avg_pmi":  round(float(sub["pmi_score"].mean()),4),
            }

        return {
            "text_column":    tc,
            "rows_analysed":  len(df),
            "sentiment_dist": df["sentiment"].value_counts().to_dict(),
            "aspect_dist":    df["aspect"].value_counts().to_dict(),
            "emotion_dist":   df["emotion"].value_counts().to_dict(),
            "absa":           absa,
            "sample_rows":    df[[tc,"sentiment","aspect","emotion","pmi_score"]].head(20).to_dict("records"),
        }
