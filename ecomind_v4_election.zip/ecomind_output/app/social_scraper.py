"""
social_scraper.py
-----------------
Free social-media scrapers that work from a URL.

YouTube   -> official YouTube Data API v3 (free, 10,000 units/day)
Instagram -> public oEmbed API  (completely free, NO API key needed)

Both return a uniform dict:
    {
        "platform":   "youtube" | "instagram",
        "source_url": str,
        "title":      str,
        "items":      [{"text": str, "author": str, "likes": int}, ...],
        "count":      int,
        "error":      str | None,
    }
"""
from __future__ import annotations
import logging, re
from urllib.parse import urlparse, parse_qs

logger = logging.getLogger(__name__)


# ── helpers ────────────────────────────────────────────────────────────────

def _extract_yt_id(url: str):
    parsed = urlparse(url)
    if "youtu.be" in parsed.netloc:
        vid = parsed.path.lstrip("/").split("/")[0]
        return vid or None
    qs = parse_qs(parsed.query)
    if "v" in qs:
        return qs["v"][0]
    m = re.search(r"/(?:shorts|embed|v)/([A-Za-z0-9_-]{11})", parsed.path)
    return m.group(1) if m else None


def _empty(platform, url, error):
    return {
        "platform":   platform,
        "source_url": url,
        "title":      "",
        "items":      [],
        "count":      0,
        "error":      error,
    }


# ── YouTube scraper ────────────────────────────────────────────────────────

class YouTubeScraper:
    BASE = "https://www.googleapis.com/youtube/v3"

    def __init__(self, api_key: str):
        self.api_key = api_key.strip()

    def fetch(self, url: str, max_comments: int = 100) -> dict:
        vid = _extract_yt_id(url)
        if not vid:
            return _empty("youtube", url, "Could not extract video ID from URL.")
        try:
            import requests as _req
        except ImportError:
            return _empty("youtube", url, "requests library not installed.")

        # video title
        try:
            vr = _req.get(
                f"{self.BASE}/videos",
                params={"part": "snippet", "id": vid, "key": self.api_key},
                timeout=10,
            )
            vr.raise_for_status()
            vdata = vr.json()
            title = (
                vdata["items"][0]["snippet"]["title"]
                if vdata.get("items")
                else f"Video {vid}"
            )
        except Exception as e:
            logger.warning("YT title fetch failed: %s", e)
            title = f"Video {vid}"

        # comments
        items, page_token = [], None
        while len(items) < max_comments:
            batch = min(100, max_comments - len(items))
            params = {
                "part": "snippet",
                "videoId": vid,
                "maxResults": batch,
                "textFormat": "plainText",
                "order": "relevance",
                "key": self.api_key,
            }
            if page_token:
                params["pageToken"] = page_token
            try:
                r = _req.get(f"{self.BASE}/commentThreads", params=params, timeout=10)
                r.raise_for_status()
                data = r.json()
            except Exception as e:
                return _empty("youtube", url, f"API error: {e}")
            if "error" in data:
                return _empty(
                    "youtube", url,
                    f"YouTube API: {data['error'].get('message', 'error')}",
                )
            for entry in data.get("items", []):
                snip = entry["snippet"]["topLevelComment"]["snippet"]
                items.append({
                    "text":   snip.get("textDisplay", ""),
                    "author": snip.get("authorDisplayName", ""),
                    "likes":  snip.get("likeCount", 0),
                })
            page_token = data.get("nextPageToken")
            if not page_token or len(items) >= max_comments:
                break

        return {
            "platform":   "youtube",
            "source_url": url,
            "title":      title,
            "items":      items,
            "count":      len(items),
            "error":      None,
        }


# ── Instagram scraper (FREE — public oEmbed, no API key) ───────────────────

_IG_URL_RE = re.compile(
    r"https?://(www\.)?instagram\.com/(p|reel|tv)/[\w-]+/?",
    re.IGNORECASE,
)

class InstagramScraper:
    """
    Fetches caption + metadata from any PUBLIC Instagram post / reel / IGTV
    using Instagram's free oEmbed endpoint — no API key, no login required.

    Limitation: caption text only. Comments need the paid Meta Graph API.
    """
    OEMBED = "https://www.instagram.com/api/v1/oembed/"

    def fetch(self, url: str) -> dict:
        if not _IG_URL_RE.match(url):
            return _empty(
                "instagram", url,
                "Invalid Instagram URL. Expected: "
                "https://www.instagram.com/p/CODE/ or /reel/CODE/ or /tv/CODE/",
            )
        try:
            import requests as _req
        except ImportError:
            return _empty("instagram", url, "requests library not installed.")

        try:
            resp = _req.get(
                self.OEMBED,
                params={"url": url, "hidecaption": "false", "omitscript": "true"},
                headers={"User-Agent": "EcoMind/2.0 (social-analysis-tool)"},
                timeout=12,
            )
        except Exception as exc:
            return _empty("instagram", url, f"Network error: {exc}")

        if resp.status_code == 404:
            return _empty("instagram", url,
                          "Post not found — private account, deleted post, or wrong URL.")
        if resp.status_code == 401:
            return _empty("instagram", url,
                          "Instagram requires login for this content (private account).")
        if resp.status_code == 429:
            return _empty("instagram", url,
                          "Instagram rate-limit hit — please wait a few seconds and retry.")
        if resp.status_code != 200:
            return _empty("instagram", url,
                          f"Instagram oEmbed returned HTTP {resp.status_code}.")

        try:
            oembed = resp.json()
        except Exception:
            return _empty("instagram", url, "Could not parse Instagram's JSON response.")

        caption     = oembed.get("title", "")
        author_name = oembed.get("author_name", "")
        author_url  = oembed.get("author_url",  "")
        thumbnail   = oembed.get("thumbnail_url", "")

        if not caption:
            return _empty("instagram", url,
                          "No caption found — post may be private, caption-less, or removed.")

        return {
            "platform":      "instagram",
            "source_url":    url,
            "title":         caption,
            "author_name":   author_name,
            "author_url":    author_url,
            "thumbnail_url": thumbnail,
            "items": [{
                "text":   caption,
                "author": author_name,
                "likes":  0,
            }],
            "count": 1,
            "error": None,
        }


# ── Unified facade ─────────────────────────────────────────────────────────

class SocialScraper:

    def fetch_youtube(self, url: str, api_key: str, max_comments: int = 100) -> dict:
        if not api_key or api_key.strip() in ("", "YOUR_YOUTUBE_API_KEY"):
            return _empty("youtube", url, "No YouTube API key provided.")
        return YouTubeScraper(api_key).fetch(url, max_comments)

    def fetch_instagram(self, url: str) -> dict:
        """Free — no API key needed. Works on any public post / reel / tv URL."""
        return InstagramScraper().fetch(url)

    @staticmethod
    def detect_platform(url: str) -> str:
        u = url.lower()
        if "youtube.com" in u or "youtu.be" in u:
            return "youtube"
        if "instagram.com" in u:
            return "instagram"
        return "unknown"
