"""pdf_report.py — ReportLab PDF generator"""
from __future__ import annotations
import io
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

C_DARK  = colors.HexColor("#1e3a5f")
C_BLUE  = colors.HexColor("#2563eb")
C_LIGHT = colors.HexColor("#eff6ff")
C_GREEN = colors.HexColor("#16a34a")
C_RED   = colors.HexColor("#dc2626")
C_GREY  = colors.HexColor("#6b7280")
C_WHITE = colors.white

def _s():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t",parent=base["Title"],fontSize=20,textColor=C_DARK,spaceAfter=6,alignment=TA_CENTER),
        "sub":   ParagraphStyle("s",parent=base["Normal"],fontSize=11,textColor=C_GREY,spaceAfter=18,alignment=TA_CENTER),
        "h1":    ParagraphStyle("h1",parent=base["Heading1"],fontSize=13,textColor=C_BLUE,spaceBefore=14,spaceAfter=5),
        "h2":    ParagraphStyle("h2",parent=base["Heading2"],fontSize=11,textColor=C_DARK,spaceBefore=8,spaceAfter=4),
        "body":  ParagraphStyle("b",parent=base["Normal"],fontSize=9,spaceAfter=5,leading=14),
        "small": ParagraphStyle("sm",parent=base["Normal"],fontSize=8,textColor=C_GREY,spaceAfter=3),
        "cap":   ParagraphStyle("c",parent=base["Normal"],fontSize=8,textColor=C_GREY,alignment=TA_CENTER,spaceAfter=5),
    }

def _hr(story, color=C_BLUE, t=0.5):
    story.append(HRFlowable(width="100%",thickness=t,color=color,spaceAfter=5))

def _tbl(data, widths, hbg=C_BLUE):
    tbl = Table(data, colWidths=widths)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),hbg),("TEXTCOLOR",(0,0),(-1,0),C_WHITE),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,0),8),
        ("BOTTOMPADDING",(0,0),(-1,0),7),
        ("FONTNAME",(0,1),(-1,-1),"Helvetica"),("FONTSIZE",(0,1),(-1,-1),8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_WHITE,C_LIGHT]),
        ("GRID",(0,0),(-1,-1),0.4,C_GREY),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("TOPPADDING",(0,1),(-1,-1),4),("BOTTOMPADDING",(0,1),(-1,-1),4),
    ]))
    return tbl

def generate_report(platform_stats, absa_tw, emotions_tw, pmi_scores,
                    recommendations, monthly_trend=None, **kwargs) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    s = _s(); story = []

    story += [Spacer(1,.8*cm),
              Paragraph("EcoMind — Environmental Sentiment Intelligence", s["title"]),
              Paragraph("Aspect-Based Sentiment &amp; Emotion Analysis of Environmental Social Media Discussions", s["sub"])]
    _hr(story, t=1.5)
    story.append(Paragraph(
        f"<b>Team:</b> Vignesh E (3592310057) · Sakthivel V (3592310039)<br/>"
        f"<b>Programme:</b> 3rd Year AI &amp; Data Science<br/>"
        f"<b>Generated:</b> {datetime.now().strftime('%d %B %Y, %H:%M')}", s["body"]))
    story.append(Paragraph(
        "<b>IEEE Reference:</b> Amangeldi, D., Usmanova, A., &amp; Shamoi, P. (2025). "
        "Understanding Environmental Posts: Sentiment and Emotion Analysis of Social Media Data. "
        "<i>IEEE Access</i>. DOI: 10.1109/ACCESS.2024.3371585", s["small"]))
    story.append(Spacer(1,.5*cm))

    # Platform
    story.append(Paragraph("1. Dataset Overview", s["h1"])); _hr(story)
    rows = [["Platform","Total","Positive","Neutral","Negative","Pos%"]]
    for p, v in platform_stats.items():
        t = max(v["total"],1)
        rows.append([p, str(v["total"]), str(v["positive"]), str(v["neutral"]), str(v["negative"]), f"{v['positive']/t*100:.1f}%"])
    story.append(_tbl(rows,[4*cm,2.5*cm,2.5*cm,2.5*cm,2.5*cm,2*cm])); story.append(Spacer(1,.3*cm))

    # ABSA
    story.append(Paragraph("2. Aspect-Based Sentiment Analysis (ABSA)", s["h1"])); _hr(story)
    rows = [["Aspect","Total","Positive","Neutral","Negative","Avg PMI"]]
    for asp, v in absa_tw.items():
        rows.append([asp, str(v.get("total",0)), str(v.get("positive",0)), str(v.get("neutral",0)), str(v.get("negative",0)), f"{v.get('avg_polarity',0):+.4f}"])
    story.append(_tbl(rows,[4.5*cm,1.8*cm,2.2*cm,2.2*cm,2.2*cm,2.3*cm])); story.append(Spacer(1,.3*cm))

    # Emotions
    story.append(Paragraph("3. Emotion Detection Results", s["h1"])); _hr(story)
    total_e = max(sum(emotions_tw.values()),1)
    rows = [["Emotion","Count","Percentage"]]
    for emo, cnt in sorted(emotions_tw.items(), key=lambda x:-x[1]):
        rows.append([emo, str(cnt), f"{cnt/total_e*100:.1f}%"])
    story.append(_tbl(rows,[6*cm,4*cm,6.2*cm])); story.append(Spacer(1,.3*cm))

    # PMI
    story.append(Paragraph("4. PMI Semantic Orientation Scores", s["h1"])); _hr(story)
    rows = [["Keyword","PMI Score","Orientation"]]
    for w, sc in sorted(pmi_scores.items(), key=lambda x:-x[1]):
        rows.append([w, f"{sc:+.4f}", "Positive ▲" if sc >= 0 else "Negative ▼"])
    story.append(_tbl(rows,[6*cm,5*cm,5.2*cm])); story.append(Spacer(1,.3*cm))

    # Trend
    if monthly_trend:
        story.append(Paragraph("5. Monthly Sentiment Trend", s["h1"])); _hr(story)
        mn = {1:"Jan",2:"Feb",3:"Mar",4:"Apr",5:"May",6:"Jun",7:"Jul",8:"Aug",9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
        rows = [["Month","Avg PMI","Positive","Neutral","Negative","Total"]]
        for m, v in monthly_trend.items():
            rows.append([mn.get(int(m),str(m)), f"{v.get('avg_polarity',0):+.4f}", str(v.get("positive",0)), str(v.get("neutral",0)), str(v.get("negative",0)), str(v.get("total",0))])
        story.append(_tbl(rows,[2.5*cm,2.5*cm,2.5*cm,2.5*cm,2.5*cm,2.5*cm])); story.append(Spacer(1,.3*cm))

    # Recommendations
    story.append(Paragraph("6. Strategic Recommendations", s["h1"])); _hr(story)
    for r in recommendations:
        story.append(Paragraph(f"<b>{r['title']}</b>", s["h2"]))
        story.append(Paragraph(r["desc"], s["body"]))
        story.append(Paragraph(f"<i>Platform: {r['platform']}</i>", s["small"]))
        story.append(Spacer(1,.15*cm))

    story += [Spacer(1,.6*cm)]
    _hr(story, color=C_GREY, t=0.4)
    story.append(Paragraph("Generated by EcoMind Environmental Sentiment Intelligence · IEEE Access DOI 10.1109/ACCESS.2024.3371585", s["cap"]))
    doc.build(story)
    buf.seek(0)
    return buf.read()
