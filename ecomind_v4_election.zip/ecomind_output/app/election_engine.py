"""
election_engine.py
------------------
Election / Political Sentiment Analysis Engine for EcoMind.

Analyses text for:
  • Political sentiment  (pro / anti / neutral / mixed)
  • Political aspect     (Candidate, Party, Policy, Economy, Campaign, Corruption, Election Process, Other)
  • Dominant emotion     (Hope, Anger, Fear, Trust, Disgust, Anticipation, Neutral)
  • Party/candidate lean (detected from keywords)
  • Toxicity flag        (hate speech / incitement detection)
  • PMI-style score
"""
from __future__ import annotations
import re, logging
from typing import Optional

logger = logging.getLogger(__name__)

# ── Political Aspect keywords ─────────────────────────────────────────────
POL_ASPECTS: dict[str, list[str]] = {
    "Candidate":         ["candidate","leader","pm","president","cm","minister",
                          "politician","mp","mla","senator","congressman","governor",
                          "nominee","incumbent","challenger","official"],
    "Party":             ["party","bjp","congress","aap","sp","bsp","tnc","dmk","admk",
                          "nda","upa","alliance","coalition","republican","democrat",
                          "labour","tory","conservative","liberal","left","right","wing"],
    "Policy":            ["policy","law","bill","act","scheme","welfare","subsidy",
                          "tax","reform","amendment","constitution","manifesto",
                          "promise","healthcare","education","infrastructure","budget"],
    "Economy":           ["economy","inflation","unemployment","gdp","growth","recession",
                          "price","fuel","petrol","diesel","market","rupee","dollar",
                          "poverty","income","salary","jobs","employment","finance"],
    "Campaign":          ["campaign","rally","vote","election","poll","ballot",
                          "campaign trail","manifesto","slogan","advertisement",
                          "door to door","canvass","booth","evm","voting machine"],
    "Corruption":        ["corrupt","bribe","scam","scandal","fraud","money laundering",
                          "black money","nepotism","dynast","crony","illegal",
                          "arrested","chargesheet","sting","loot","embezzle"],
    "Election Process":  ["election commission","evm","vvpat","booth","counting",
                          "recount","rigging","fair election","code of conduct",
                          "model code","eci","nomination","result","declare","win","lose"],
    "Social Issues":     ["caste","religion","hindu","muslim","minority","reservation",
                          "quota","rights","freedom","protest","agitation","riot",
                          "violence","hate","community","gender","women","youth"],
}

# ── Sentiment keywords ────────────────────────────────────────────────────
POL_POS = ["win","victory","progress","development","good","great","support",
           "excellent","hope","better","achieve","success","positive","trust",
           "strong","leader","change","growth","improve","popular","honest","clean"]

POL_NEG = ["corrupt","fail","lose","scandal","crisis","bad","terrible","cheat",
           "lie","fraud","bribe","anti","protest","against","resign","incompetent",
           "disaster","threat","danger","riot","violence","hate","arrest","fake"]

# ── Emotion keywords ──────────────────────────────────────────────────────
POL_EMOTIONS: dict[str, list[str]] = {
    "Hope":        ["hope","better","change","future","progress","develop","improve",
                    "win","success","great","achieve","build","grow","positive"],
    "Anger":       ["angry","outrage","disgusted","shame","blame","corrupt","fraud",
                    "liar","cheat","criminal","resign","demand","protest","unacceptable"],
    "Fear":        ["fear","threat","danger","violence","riot","instability","crisis",
                    "attack","bomb","terror","unsafe","panic","scared","worry"],
    "Trust":       ["trust","honest","reliable","transparent","accountable","fact",
                    "data","evidence","proven","credible","fair","integrity","clean"],
    "Disgust":     ["disgusting","shameful","horrifying","appalling","sick","dirty",
                    "revolting","filthy","low","cheap","petty","stooping"],
    "Anticipation":["expect","soon","next","upcoming","predict","forecast","watch",
                    "monitor","result","await","likely","probably","prepare"],
    "Neutral":     [],
}

# ── Toxicity keywords ─────────────────────────────────────────────────────
TOXIC_WORDS = ["kill","murder","shoot","bomb","attack","riot","lynch","destroy",
               "hang","burn","slaughter","genocide","terrorist","traitor"]

# ── Known elections (for context) ────────────────────────────────────────
ELECTIONS: dict[str, dict] = {
    "India 2024":       {"country":"India",  "type":"General Election", "year":2024},
    "India 2019":       {"country":"India",  "type":"General Election", "year":2019},
    "US 2024":          {"country":"USA",    "type":"Presidential",     "year":2024},
    "US 2020":          {"country":"USA",    "type":"Presidential",     "year":2020},
    "UK 2024":          {"country":"UK",     "type":"General Election", "year":2024},
    "Tamil Nadu 2021":  {"country":"India",  "type":"State Election",   "year":2021},
    "Delhi 2025":       {"country":"India",  "type":"State Election",   "year":2025},
    "General":          {"country":"Unknown","type":"General",          "year":0},
}


class ElectionAnalyser:

    def _clean(self, text: str) -> str:
        t = str(text).lower()
        t = re.sub(r"http\S+|www\S+", "", t)
        t = re.sub(r"@\w+", "", t)
        t = re.sub(r"#(\w+)", r"\1", t)
        t = re.sub(r"[^a-z0-9\s]", " ", t)
        return re.sub(r"\s+", " ", t).strip()

    def _sentiment(self, text: str) -> tuple[str, float]:
        t = self._clean(text)
        p = sum(1 for w in POL_POS if w in t)
        n = sum(1 for w in POL_NEG if w in t) * 1.2
        if p > 0 and n > 0:
            score = (p - n) / (p + n)
            return ("mixed", round(score, 4))
        if p > n:
            score = p / (p + n + 1e-9)
            return ("pro", round(score, 4))
        if n > p:
            score = -(n / (p + n + 1e-9))
            return ("anti", round(score, 4))
        return ("neutral", 0.0)

    def _aspect(self, text: str) -> str:
        t = self._clean(text)
        scores = {asp: sum(1 for kw in kws if kw in t)
                  for asp, kws in POL_ASPECTS.items()}
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 else "Other"

    def _emotion(self, text: str) -> tuple[str, dict]:
        t = self._clean(text)
        scores = {emo: sum(1 for kw in kws if kw in t)
                  for emo, kws in POL_EMOTIONS.items() if kws}
        dominant = max(scores, key=scores.get) if max(scores.values(), default=0) > 0 else "Neutral"
        return dominant, scores

    def _toxicity(self, text: str) -> bool:
        t = self._clean(text)
        return any(w in t for w in TOXIC_WORDS)

    def _pmi(self, text: str) -> float:
        t = self._clean(text).split()
        n = max(len(t), 1)
        pos_s = sum(t.count(w) / n for w in POL_POS if w in t)
        neg_s = sum(t.count(w) / n for w in POL_NEG if w in t)
        raw   = (pos_s - neg_s) / (pos_s + neg_s + 1e-9)
        return round(max(-1.0, min(1.0, raw)), 4)

    def analyse(self, text: str, election: str = "General") -> dict:
        sentiment, pol_score = self._sentiment(text)
        aspect               = self._aspect(text)
        emotion, emo_scores  = self._emotion(text)
        toxic                = self._toxicity(text)
        pmi                  = self._pmi(text)
        election_info        = ELECTIONS.get(election, ELECTIONS["General"])

        return {
            "text_preview":  text[:200],
            "election":      election,
            "election_info": election_info,
            "sentiment":     sentiment,          # pro / anti / neutral / mixed
            "polarity_score":pol_score,
            "aspect":        aspect,
            "emotion":       emotion,
            "emotion_scores":emo_scores,
            "pmi_score":     pmi,
            "is_toxic":      toxic,
            "toxic_warning": "⚠️ Potentially toxic content detected." if toxic else None,
        }

    def analyse_batch(self, items: list[dict], election: str = "General") -> dict:
        """Batch NLP for YouTube comments or Instagram list."""
        sent_dist  = {"pro": 0, "anti": 0, "neutral": 0, "mixed": 0}
        emo_dist   = {}
        asp_dist   = {}
        toxic_count = 0
        pmi_sum    = 0.0
        labelled   = []

        for item in items[:200]:
            text = item.get("text", "")
            if not text:
                continue
            a = self.analyse(text, election)
            sent_dist[a["sentiment"]] = sent_dist.get(a["sentiment"], 0) + 1
            emo_dist[a["emotion"]]    = emo_dist.get(a["emotion"], 0) + 1
            asp_dist[a["aspect"]]     = asp_dist.get(a["aspect"], 0) + 1
            pmi_sum += a["pmi_score"]
            if a["is_toxic"]:
                toxic_count += 1
            labelled.append({
                "text":      text[:120],
                "author":    item.get("author", ""),
                "likes":     item.get("likes", 0),
                "sentiment": a["sentiment"],
                "aspect":    a["aspect"],
                "emotion":   a["emotion"],
                "pmi_score": a["pmi_score"],
                "is_toxic":  a["is_toxic"],
            })

        n = max(len(labelled), 1)
        return {
            "sentiment_dist": sent_dist,
            "emotion_dist":   emo_dist,
            "aspect_dist":    asp_dist,
            "avg_pmi":        round(pmi_sum / n, 4),
            "toxic_count":    toxic_count,
            "labelled_items": labelled[:20],
        }

    def overview(self) -> dict:
        """Pre-computed demo stats for the Election dashboard overview cards."""
        return {
            "elections_tracked": 6,
            "total_posts_analysed": 42800,
            "avg_toxicity_pct": 8.4,
            "most_discussed_aspect": "Policy",
            "dominant_emotion": "Anticipation",
            "pro_sentiment_pct": 38.2,
            "anti_sentiment_pct": 34.7,
            "neutral_pct": 27.1,
            "top_elections": [
                {"name": "India 2024",      "posts": 18400, "top_emotion": "Anticipation", "toxicity_pct": 9.1},
                {"name": "US 2024",         "posts": 14200, "top_emotion": "Anger",        "toxicity_pct": 11.3},
                {"name": "UK 2024",         "posts": 6100,  "top_emotion": "Hope",         "toxicity_pct": 5.2},
                {"name": "Tamil Nadu 2021", "posts": 3100,  "top_emotion": "Anticipation", "toxicity_pct": 7.8},
                {"name": "Delhi 2025",      "posts": 1000,  "top_emotion": "Hope",         "toxicity_pct": 6.4},
            ],
            "aspect_breakdown": {
                "Candidate":        8900,
                "Policy":           11200,
                "Party":            7400,
                "Economy":          6100,
                "Campaign":         4200,
                "Corruption":       2800,
                "Election Process": 1400,
                "Social Issues":    800,
            },
            "sentiment_trend": {
                "Jan": {"pro": 38, "anti": 35, "neutral": 27},
                "Feb": {"pro": 40, "anti": 33, "neutral": 27},
                "Mar": {"pro": 36, "anti": 37, "neutral": 27},
                "Apr": {"pro": 42, "anti": 31, "neutral": 27},
                "May": {"pro": 39, "anti": 34, "neutral": 27},
                "Jun": {"pro": 37, "anti": 35, "neutral": 28},
            },
        }
