/* analyzer.js — Live Analyzer page logic */
'use strict';

let _selectedFile   = null;
let _batchResults   = null;
let _urlResults     = null;
let _batchSentChart = null;
let _batchEmoChart  = null;
let _batchAbsaChart = null;

const C = {
  blue:'#2563eb', green:'#16a34a', red:'#dc2626',
  orange:'#d97706', grey:'#94a3b8', border:'#e2e8f0',
  purple:'#7c3aed',
};
const rgba = (hex, a) => {
  const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${a})`;
};

// ── Tab switching ─────────────────────────────────────────────────────────

function switchTab(name) {
  document.querySelectorAll('.ana-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.ana-panel').forEach(p => p.classList.remove('active'));
  document.querySelector(`.ana-tab[onclick*="${name}"]`).classList.add('active');
  document.getElementById('panel-' + name).classList.add('active');
}

// ── Sidebar PDF / toggle ──────────────────────────────────────────────────

function downloadPDF() {
  const a = document.createElement('a');
  a.href = '/api/report/pdf';
  a.download = 'ecomind_report.pdf';
  a.click();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ── Drop zone / file select ───────────────────────────────────────────────

function handleDrop(e) {
  e.preventDefault();
  document.getElementById('drop-zone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) setFile(file);
}

function handleFileSelect(input) {
  if (input.files[0]) setFile(input.files[0]);
}

function setFile(file) {
  if (!file.name.endsWith('.csv')) {
    alert('Please upload a .csv file.');
    return;
  }
  _selectedFile = file;
  const info = document.getElementById('csv-file-info');
  info.style.display = 'block';
  info.innerHTML = `📂 <strong>${file.name}</strong> — ${(file.size/1024).toFixed(1)} KB selected`;
  document.getElementById('run-csv-btn').style.display = 'inline-flex';
}

// ── Batch CSV analysis ────────────────────────────────────────────────────

async function runBatchAnalysis() {
  if (!_selectedFile) return;
  const btn = document.getElementById('run-csv-btn');
  btn.textContent = '⏳ Analysing…';
  btn.disabled = true;

  try {
    const formData = new FormData();
    formData.append('file', _selectedFile);

    const res = await fetch('/api/analyse/batch', { method:'POST', body: formData });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || 'Server error');
    }

    _batchResults = await res.json();
    renderBatchResults(_batchResults);
  } catch (err) {
    alert('Error: ' + err.message);
  } finally {
    btn.textContent = '⚡ Run Full Pipeline Analysis';
    btn.disabled = false;
  }
}

function renderBatchResults(data) {
  const box = document.getElementById('csv-results');
  box.style.display = 'block';
  box.scrollIntoView({ behavior:'smooth', block:'nearest' });

  // KPI cards
  const kpiRow = document.getElementById('batch-kpi-row');
  const sentDist = data.sentiment_dist || {};
  const total = data.rows_analysed || 0;
  kpiRow.innerHTML = [
    { val: total,                      lbl: 'Rows Analysed' },
    { val: sentDist.positive || 0,     lbl: 'Positive' },
    { val: sentDist.negative || 0,     lbl: 'Negative' },
    { val: Object.keys(data.absa || {}).length, lbl: 'Aspects Found' },
  ].map(k => `<div class="res-kpi"><div class="rk-val">${k.val}</div><div class="rk-lbl">${k.lbl}</div></div>`).join('');

  // Sentiment doughnut
  if (_batchSentChart) _batchSentChart.destroy();
  const sentEl = document.getElementById('batch-sent-chart');
  if (sentEl) {
    _batchSentChart = new Chart(sentEl, {
      type: 'doughnut',
      data: {
        labels: ['Positive','Neutral','Negative'],
        datasets: [{ data: [sentDist.positive||0, sentDist.neutral||0, sentDist.negative||0],
          backgroundColor: [rgba(C.green,.8), rgba(C.grey,.6), rgba(C.red,.8)],
          borderColor: ['#fff','#fff','#fff'], borderWidth: 3 }],
      },
      options: { responsive:true, maintainAspectRatio:false, cutout:'65%', plugins:{legend:{labels:{font:{size:11}}}} },
    });
  }

  // Emotion bar chart
  if (_batchEmoChart) _batchEmoChart.destroy();
  const emoDist = data.emotion_dist || {};
  const emoEl = document.getElementById('batch-emo-chart');
  if (emoEl) {
    const emoKeys  = Object.keys(emoDist);
    const emoColors= {'Fear':C.purple,'Anger':C.red,'Hope':C.green,'Trust':C.blue,'Sadness':'#3b82f6','Anticipation':C.orange,'Surprise':'#f59e0b','Neutral':C.grey,'Disgust':'#854d0e'};
    _batchEmoChart = new Chart(emoEl, {
      type: 'bar', indexAxis: 'y',
      data: {
        labels: emoKeys,
        datasets: [{ label:'Count', data: Object.values(emoDist),
          backgroundColor: emoKeys.map(e => rgba(emoColors[e]||C.blue, .75)),
          borderColor:     emoKeys.map(e => emoColors[e]||C.blue),
          borderWidth:1, borderRadius:4 }],
      },
      options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ x:{grid:{color:C.border}}, y:{grid:{color:C.border}} } },
    });
  }

  // ABSA grouped bar
  if (_batchAbsaChart) _batchAbsaChart.destroy();
  const absa = data.absa || {};
  const aspKeys = Object.keys(absa).filter(a => a !== 'Other' && a !== 'General Environment');
  const absaEl = document.getElementById('batch-absa-chart');
  if (absaEl && aspKeys.length > 0) {
    _batchAbsaChart = new Chart(absaEl, {
      type: 'bar',
      data: {
        labels: aspKeys,
        datasets: [
          { label:'Positive', data: aspKeys.map(a => absa[a]?.positive||0), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:4 },
          { label:'Neutral',  data: aspKeys.map(a => absa[a]?.neutral||0),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1 },
          { label:'Negative', data: aspKeys.map(a => absa[a]?.negative||0), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1 },
        ],
      },
      options: { responsive:true, maintainAspectRatio:false, scales:{ x:{grid:{color:C.border}}, y:{grid:{color:C.border}} } },
    });
  }

  // Sample rows table
  const tbl = document.getElementById('batch-table');
  if (tbl && data.sample_rows?.length > 0) {
    const textCol = data.text_column;
    tbl.innerHTML = `
      <thead><tr><th>#</th><th>Text</th><th>Sentiment</th><th>Aspect</th><th>Emotion</th><th>PMI</th></tr></thead>
      <tbody>
        ${data.sample_rows.map((row, i) => `
          <tr>
            <td>${i+1}</td>
            <td title="${escHtml(String(row[textCol]||''))}">${escHtml(String(row[textCol]||'').substring(0,80))}…</td>
            <td><span class="chip chip-${row.sentiment}">${row.sentiment}</span></td>
            <td>${row.aspect}</td>
            <td>${row.emotion}</td>
            <td style="font-family:'JetBrains Mono',monospace;font-size:11px">${Number(row.pmi_score).toFixed(4)}</td>
          </tr>`).join('')}
      </tbody>`;
  }
}

async function downloadBatchPDF() {
  if (!_batchResults) return;
  const payload = {
    platform_stats: { Batch: { positive: _batchResults.sentiment_dist?.positive||0, negative: _batchResults.sentiment_dist?.negative||0, neutral: _batchResults.sentiment_dist?.neutral||0, total: _batchResults.rows_analysed||0 } },
    absa: _batchResults.absa || {},
    emotions: _batchResults.emotion_dist || {},
  };
  const res = await fetch('/api/report/batch-pdf', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const blob = await res.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'ecomind_batch_report.pdf';
  a.click();
}

// ── URL Analysis ──────────────────────────────────────────────────────────

function setURL(url) { document.getElementById('url-input').value = url; }

async function runURLAnalysis() {
  const url = document.getElementById('url-input').value.trim();
  if (!url) { alert('Please enter a URL.'); return; }

  document.getElementById('url-loading').style.display = 'flex';
  document.getElementById('url-results').style.display = 'none';

  try {
    const res = await fetch('/api/analyse/url', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ url }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || 'Server error');
    }
    const data = await res.json();
    _urlResults = data;
    renderURLResult(data);
  } catch (err) {
    alert('Error: ' + err.message);
  } finally {
    document.getElementById('url-loading').style.display = 'none';
  }
}

function renderURLResult(data) {
  const box = document.getElementById('url-results');
  box.style.display = 'block';

  document.getElementById('url-meta-box').innerHTML = `
    <strong>${escHtml(data.title)}</strong><br>
    <span style="font-size:12px;color:#64748b">${escHtml(data.url)}</span>
    &nbsp;·&nbsp; <span style="font-size:12px">${data.word_count} words</span><br>
    <span style="font-size:12px;color:#334155;margin-top:6px;display:block">"${escHtml(data.text_preview)}…"</span>`;

  const sentClass = data.sentiment === 'positive' ? 'chip-pos' : data.sentiment === 'negative' ? 'chip-neg' : 'chip-neu';
  document.getElementById('url-chips').innerHTML = `
    <span class="chip ${sentClass}">Sentiment: ${data.sentiment.toUpperCase()}</span>
    <span class="chip chip-asp">Aspect: ${data.aspect}</span>
    <span class="chip chip-emo">Emotion: ${data.emotion}</span>
    <span class="chip chip-pmi">BERT: ${data.bert_label} (${(data.bert_score*100).toFixed(0)}%)</span>
    <span class="chip chip-pmi">PMI: ${data.pmi_score >= 0 ? '+' : ''}${data.pmi_score}</span>`;

  const pol = data.pmi_score;
  document.getElementById('url-pol-score').textContent = (pol >= 0 ? '+' : '') + pol.toFixed(4);
  document.getElementById('url-pol-score').style.color = pol > 0.05 ? C.green : pol < -0.05 ? C.red : C.grey;
  document.getElementById('url-pol-needle').style.left = ((pol + 1) / 2 * 100) + '%';

  document.getElementById('url-detail').innerHTML = `
    <strong>🔬 Model:</strong> ${data.model}<br>
    <strong>🧠 Emotion:</strong> ${data.emotion} — dominant emotional tone detected in the scraped text<br>
    <strong>📌 Aspect:</strong> ${data.aspect} — primary environmental topic identified<br>
    <strong>📐 PMI Score:</strong> ${pol >= 0 ? '+' : ''}${pol.toFixed(4)} — ${pol > 0.05 ? 'positive semantic orientation (aligned with solution/hope language)' : pol < -0.05 ? 'negative semantic orientation (aligned with crisis/threat language)' : 'neutral/mixed sentiment balance'}<br>
    <strong>🎯 BERT:</strong> ${data.bert_label} with ${(data.bert_score*100).toFixed(1)}% confidence`;
}

async function downloadURLPDF() {
  if (!_urlResults) return;
  const asp = _urlResults.aspect || 'General Environment';
  const payload = {
    platform_stats: { URL: { positive: _urlResults.sentiment==='positive'?1:0, negative: _urlResults.sentiment==='negative'?1:0, neutral: _urlResults.sentiment==='neutral'?1:0, total:1 } },
    absa: { [asp]: { positive: _urlResults.sentiment==='positive'?1:0, negative: _urlResults.sentiment==='negative'?1:0, neutral: _urlResults.sentiment==='neutral'?1:0, total:1, avg_polarity: _urlResults.pmi_score } },
    emotions: { [_urlResults.emotion]: 1 },
  };
  const res = await fetch('/api/report/batch-pdf', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
  const blob = await res.blob();
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download='ecomind_url_report.pdf'; a.click();
}

// ── Quick text analysis ───────────────────────────────────────────────────

function loadQTExample(type) {
  const ex = {
    neg: "The alarming rate of global warming is catastrophic. Arctic sea ice is at record lows. Climate scientists warn of devastating ecosystem collapse, mass extinction of species and irreversible damage if we don't urgently cut carbon emissions. The crisis is an existential emergency that demands immediate action.",
    pos: "Incredible progress on renewable energy this year! Solar and wind power are now cheaper than fossil fuels globally. Sustainable technology is creating millions of green jobs and helping communities protect their biodiversity. There is real hope for a clean future with proper environmental action.",
  };
  document.getElementById('qt-input').value = ex[type] || '';
}

async function runQuickText() {
  const text = document.getElementById('qt-input').value.trim();
  if (!text) return;

  document.getElementById('qt-loading').style.display = 'flex';
  document.getElementById('qt-results').style.display = 'none';

  try {
    const res = await fetch('/api/analyse/text', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ text }),
    });
    if (!res.ok) { const e = await res.json(); throw new Error(e.detail); }
    const data = await res.json();
    renderQTResult(data);
  } catch (err) {
    alert('Error: ' + err.message);
  } finally {
    document.getElementById('qt-loading').style.display = 'none';
  }
}

function renderQTResult(data) {
  const box = document.getElementById('qt-results');
  box.style.display = 'block';
  const sentClass = data.sentiment==='positive'?'chip-pos':data.sentiment==='negative'?'chip-neg':'chip-neu';
  document.getElementById('qt-chips').innerHTML = `
    <span class="chip ${sentClass}">Sentiment: ${data.sentiment.toUpperCase()}</span>
    <span class="chip chip-asp">Aspect: ${data.aspect}</span>
    <span class="chip chip-emo">Emotion: ${data.emotion}</span>
    <span class="chip chip-pmi">BERT: ${data.bert_label} (${(data.bert_score*100).toFixed(0)}%)</span>
    <span class="chip chip-pmi">PMI: ${data.pmi_score>=0?'+':''}${data.pmi_score}</span>`;
  const pol = data.pmi_score;
  document.getElementById('qt-pol-score').textContent = (pol>=0?'+':'')+pol.toFixed(4);
  document.getElementById('qt-pol-score').style.color = pol>0.05?C.green:pol<-0.05?C.red:C.grey;
  document.getElementById('qt-pol-needle').style.left = ((pol+1)/2*100)+'%';
  document.getElementById('qt-detail').innerHTML = `
    <strong>Model:</strong> ${data.model} &nbsp;|&nbsp; <strong>BERT confidence:</strong> ${(data.bert_score*100).toFixed(1)}%<br>
    <strong>Emotion:</strong> ${data.emotion} — ${emotionExplain(data.emotion)}<br>
    <strong>PMI Score:</strong> ${pol>=0?'+':''}${pol.toFixed(4)} — ${pol>0.05?'Positive semantic orientation.':pol<-0.05?'Negative semantic orientation.':'Neutral/mixed.'}<br>
    <strong>IEEE Method:</strong> SO(w) = Σ PMI(w, P) − Σ PMI(w, N) / freq(w) — PMI accuracy 65% outperforms VADER 64% on env. text (Amangeldi et al., 2025)`;
}

function emotionExplain(emo) {
  const map = { Fear:'alarming posts about tipping points, extinction risk', Anger:'frustration at inaction, greenwashing, lobbying', Hope:'positive news about renewables, community action', Trust:'posts citing science, reports, expert evidence', Sadness:'mourning biodiversity loss, disaster aftermath', Anticipation:'watching policy, monitoring trends', Surprise:'unprecedented, unexpected events', Neutral:'balanced or factual reporting', Disgust:'revolting environmental conditions or behaviour' };
  return map[emo] || '';
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
