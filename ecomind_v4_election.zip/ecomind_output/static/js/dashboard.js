/* dashboard.js — EcoMind Dashboard
   Fetches /api/* endpoints and renders all charts & DOM elements.
   Falls back to built-in sample data if the API is loading. */
'use strict';

Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.font.size   = 11;
Chart.defaults.color       = '#64748b';

const C = {
  blue:'#2563eb', blueLt:'#3b82f6', green:'#16a34a',
  red:'#dc2626',  orange:'#d97706', grey:'#94a3b8',
  purple:'#7c3aed', teal:'#0891b2', border:'#e2e8f0',
};

const rgba = (hex, a) => {
  const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${a})`;
};

// ── Sample data (used if API call fails) ──────────────────────────────────
const SAMPLE = {
  overview: {
    total_posts:18923, twitter_total:396, youtube_total:18408, instagram_total:119,
    twitter_neg_pct:15.4, twitter_pos_pct:36.6, youtube_pos_pct:62.1,
    dominant_emotion:"Anticipation", top_aspect:"Climate Change",
    pmi_top_positive:"sustainable", pmi_top_negative:"plastic",
    sentiment_accuracy:88, emotion_accuracy:85,
  },
  platform: {
    Twitter:   {positive:145, neutral:190, negative:61,  total:396,  pos_pct:36.6, neu_pct:48.0, neg_pct:15.4},
    YouTube:   {positive:11432,neutral:4638,negative:2338,total:18408,pos_pct:62.1, neu_pct:25.2, neg_pct:12.7},
    Instagram: {positive:43,  neutral:76,  negative:0,   total:119,  pos_pct:36.1, neu_pct:63.9, neg_pct:0.0},
  },
  absa: {
    twitter: {
      "Climate Change":   {positive:144,neutral:190,negative:61, total:395,avg_polarity:0.042},
      "Air Quality":      {positive:18, neutral:16, negative:24, total:58, avg_polarity:-0.031},
      "Plastic & Waste":  {positive:14, neutral:12, negative:21, total:47, avg_polarity:-0.019},
      "Renewable Energy": {positive:32, neutral:14, negative:7,  total:53, avg_polarity:0.087},
      "Biodiversity":     {positive:24, neutral:17, negative:9,  total:50, avg_polarity:0.065},
      "Sustainability":   {positive:38, neutral:20, negative:8,  total:66, avg_polarity:0.102},
    },
    youtube: {
      "Climate Change":   {positive:312,neutral:245,negative:198,total:755},
      "Air Quality":      {positive:89, neutral:71, negative:156,total:316},
      "Plastic & Waste":  {positive:145,neutral:98, negative:189,total:432},
      "Renewable Energy": {positive:423,neutral:201,negative:87, total:711},
      "Biodiversity":     {positive:234,neutral:142,negative:67, total:443},
      "Sustainability":   {positive:567,neutral:289,negative:134,total:990},
    },
  },
  emotions: {
    distribution: {Neutral:170, Anticipation:69, Hope:56, Sadness:41, Anger:22, Trust:20, Fear:14, Surprise:4},
    heatmap: {
      "Climate Change":   {Fear:14,Anger:22,Hope:53,Trust:20,Sadness:41,Anticipation:68,Surprise:4,Neutral:167,Disgust:2},
      "Air Quality":      {Fear:8, Anger:12,Hope:5, Trust:4, Sadness:10,Anticipation:6, Surprise:2,Neutral:11, Disgust:3},
      "Plastic & Waste":  {Fear:5, Anger:8, Hope:8, Trust:5, Sadness:12,Anticipation:5, Surprise:2,Neutral:10, Disgust:6},
      "Renewable Energy": {Fear:2, Anger:3, Hope:28,Trust:15,Sadness:3, Anticipation:12,Surprise:3,Neutral:14, Disgust:0},
      "Biodiversity":     {Fear:3, Anger:2, Hope:18,Trust:14,Sadness:8, Anticipation:8, Surprise:3,Neutral:17, Disgust:1},
      "Sustainability":   {Fear:1, Anger:2, Hope:30,Trust:18,Sadness:4, Anticipation:14,Surprise:4,Neutral:20, Disgust:0},
    },
  },
  trends: {
    "1":{avg_polarity:0.0711,positive:14,negative:5,neutral:18,total:37},
    "2":{avg_polarity:0.0652,positive:12,negative:4,neutral:16,total:32},
    "3":{avg_polarity:-0.0086,positive:8,negative:9,neutral:17,total:34},
    "4":{avg_polarity:0.0463,positive:13,negative:5,neutral:16,total:34},
    "5":{avg_polarity:0.0474,positive:12,negative:5,neutral:15,total:32},
    "6":{avg_polarity:0.0963,positive:16,negative:3,neutral:12,total:31},
    "7":{avg_polarity:0.0753,positive:14,negative:4,neutral:14,total:32},
    "8":{avg_polarity:0.0408,positive:12,negative:5,neutral:16,total:33},
    "9":{avg_polarity:0.0284,positive:11,negative:6,neutral:17,total:34},
    "10":{avg_polarity:0.0015,positive:9,negative:8,neutral:18,total:35},
    "11":{avg_polarity:-0.0067,positive:8,negative:9,neutral:16,total:33},
    "12":{avg_polarity:0.0478,positive:12,negative:5,neutral:16,total:33},
  },
  recs: [
    {type:"warning",color:"#f59e0b",title:"High Negativity Alert: Air Quality",desc:"Discussions around Air Quality carry the highest negative sentiment ratio. NGO messaging should lead with empathy and concrete solution pathways rather than problem descriptions.",platform:"All Platforms"},
    {type:"success",color:"#22c55e",title:"Content Opportunity: Sustainability",desc:"Sustainability generates the most positive engagement (PMI: +0.102). Amplify success stories, community initiatives and measurable wins in this domain.",platform:"Twitter · Instagram"},
    {type:"info",color:"#3b82f6",title:"YouTube: Primary Awareness Platform",desc:"62.1% of YouTube environmental comments are positive — the highest across all platforms. Deploy educational video content, explainer series and solution-focused documentaries here for maximum reach.",platform:"YouTube"},
    {type:"info",color:"#6366f1",title:"Twitter: Crisis Communication Channel",desc:"15.4% negativity on Twitter makes it optimal for urgent climate alerts, policy demands and rapid-response environmental campaigns.",platform:"Twitter"},
    {type:"action",color:"#8b5cf6",title:"Narrative Shift: Fear → Hope Framing",desc:"Fear and Sadness dominate negative posts. Solution-framing outperforms doom-framing. Pivot from crisis language to renewable energy wins and biodiversity recovery stories.",platform:"All Platforms"},
    {type:"action",color:"#14b8a6",title:"Biodiversity: Underserved Niche with High Trust",desc:"Biodiversity posts carry the highest Trust scores yet are underrepresented in content volume. NGOs focused on conservation should invest more in biodiversity storytelling.",platform:"Instagram · YouTube"},
  ],
};

const ASPECT_META = {
  "Climate Change":   {icon:"🌡️", color:"#dc2626"},
  "Air Quality":      {icon:"💨", color:"#d97706"},
  "Plastic & Waste":  {icon:"♻️", color:"#f59e0b"},
  "Renewable Energy": {icon:"⚡", color:"#16a34a"},
  "Biodiversity":     {icon:"🌿", color:"#0891b2"},
  "Sustainability":   {icon:"🌱", color:"#2563eb"},
};

const EMO_META = {
  Neutral:     {emoji:"😐", color:"#94a3b8"},
  Anticipation:{emoji:"🤔", color:"#d97706"},
  Hope:        {emoji:"✨", color:"#16a34a"},
  Sadness:     {emoji:"😔", color:"#3b82f6"},
  Anger:       {emoji:"😠", color:"#dc2626"},
  Trust:       {emoji:"🤝", color:"#0891b2"},
  Fear:        {emoji:"😨", color:"#7c3aed"},
  Surprise:    {emoji:"😲", color:"#f59e0b"},
  Disgust:     {emoji:"🤢", color:"#854d0e"},
};

// ── Navigation ─────────────────────────────────────────────────────────────
const SEC_NAMES = {
  overview:"Overview", absa:"ABSA", emotion:"Emotion Detection",
  trends:"Time Trend Analysis", platforms:"Platform Comparison",
  recommendations:"NGO Recommendations",
};

function goSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item[data-section]').forEach(n => n.classList.remove('active'));
  const sec = document.getElementById('sec-' + id);
  if (sec) sec.classList.add('active');
  const nav = document.querySelector(`.nav-item[data-section="${id}"]`);
  if (nav) nav.classList.add('active');
  const bc = document.getElementById('bc-title');
  if (bc) bc.textContent = SEC_NAMES[id] || id;
  window.scrollTo({top:0, behavior:'smooth'});
}

document.querySelectorAll('.nav-item[data-section]').forEach(item => {
  item.addEventListener('click', e => { e.preventDefault(); goSection(item.dataset.section); });
});

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

async function downloadPDF() {
  const a = document.createElement('a');
  a.href = '/api/report/pdf';
  a.download = 'ecomind_analysis_report.pdf';
  a.click();
}

// ── API fetch helper ────────────────────────────────────────────────────────
async function fetchJSON(url, fallback) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    console.warn(`API ${url} failed, using sample data:`, e.message);
    return fallback;
  }
}

// ── KPI grid ────────────────────────────────────────────────────────────────
function buildKPIGrid(d) {
  const g = document.getElementById('kpi-grid');
  if (!g) return;
  const items = [
    {icon:'🐦', val:d.twitter_total.toLocaleString(),   label:'Twitter Posts',     sub:'Climate & Environment',    accent:'#2563eb', badge:'2020 Dataset',    bc:'badge-blue'},
    {icon:'▶',  val:d.youtube_total.toLocaleString(),   label:'YouTube Comments',  sub:'Labelled sentiment',       accent:'#dc2626', badge:'Largest dataset', bc:'badge-red'},
    {icon:'📸', val:d.instagram_total.toLocaleString(), label:'Instagram Posts',   sub:'Engagement metrics',       accent:'#7c3aed', badge:'Captions+Tags',   bc:'badge-orange'},
    {icon:'🎯', val:d.sentiment_accuracy+'%',           label:'Sentiment Accuracy',sub:'BERT-enhanced PMI',        accent:'#16a34a', badge:'vs VADER 64%',    bc:'badge-green'},
    {icon:'🧠', val:d.dominant_emotion,                 label:'Dominant Emotion',  sub:'Consistent with IEEE',     accent:'#d97706', badge:'All platforms',   bc:'badge-orange'},
    {icon:'🌡️', val:d.top_aspect,                      label:'Top Aspect',        sub:'Most discussed topic',     accent:'#dc2626', badge:'Cross-platform',  bc:'badge-red'},
    {icon:'📈', val:'+'+d.pmi_top_positive,             label:'Highest PMI Word',  sub:'Most positive keyword',    accent:'#16a34a', badge:'Semantic +',      bc:'badge-green'},
    {icon:'📉', val:d.pmi_top_negative,                 label:'Lowest PMI Word',   sub:'Most negative keyword',    accent:'#dc2626', badge:'Semantic −',      bc:'badge-red'},
  ];
  g.innerHTML = items.map(k=>`
    <div class="kpi-card" style="--kpi-accent:${k.accent}">
      <div class="kpi-icon">${k.icon}</div>
      <div class="kpi-val">${k.val}</div>
      <div class="kpi-label">${k.label}</div>
      <div class="kpi-sub">${k.sub}</div>
      <span class="kpi-badge ${k.bc}">${k.badge}</span>
    </div>`).join('');
}

// ── Overview charts ─────────────────────────────────────────────────────────
function buildOverviewPlatform(platform) {
  const el = document.getElementById('ov-plat-chart');
  if (!el) return;
  const labels = Object.keys(platform);
  new Chart(el, {
    type:'bar',
    data:{
      labels,
      datasets:[
        {label:'Positive', data:labels.map(p=>platform[p].positive), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:5},
        {label:'Neutral',  data:labels.map(p=>platform[p].neutral),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1, borderRadius:5},
        {label:'Negative', data:labels.map(p=>platform[p].negative), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1, borderRadius:5},
      ],
    },
    options:{responsive:true, maintainAspectRatio:false,
      plugins:{legend:{labels:{font:{size:11}}}},
      scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}}},
    },
  });
}

function buildOverviewRadar(dist) {
  const el = document.getElementById('ov-emo-radar');
  if (!el) return;
  const keys = Object.keys(dist);
  new Chart(el, {
    type:'radar',
    data:{
      labels:keys,
      datasets:[{label:'Emotion Intensity', data:Object.values(dist),
        backgroundColor:rgba(C.blue,.1), borderColor:C.blue,
        pointBackgroundColor:C.blue, pointRadius:4, borderWidth:2}],
    },
    options:{responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{r:{ticks:{backdropColor:'transparent',stepSize:40}, pointLabels:{font:{size:11}}}},
    },
  });
}

// ── ABSA section ────────────────────────────────────────────────────────────
function buildABSA(absa) {
  // Aspect cards
  const grid = document.getElementById('asp-cards');
  if (grid) {
    const aspects = Object.keys(absa.twitter).filter(a=>a!=='Other');
    grid.innerHTML = aspects.map(name=>{
      const v    = absa.twitter[name];
      const meta = ASPECT_META[name]||{icon:'🌍',color:C.blue};
      const t    = Math.max(v.total,1);
      const pp   = Math.round(v.positive/t*100);
      const np   = Math.round(v.negative/t*100);
      const ep   = Math.round(v.neutral/t*100);
      const pol  = v.avg_polarity||0;
      const pc   = pol>=0?C.green:C.red;
      return `
        <div class="asp-card" style="--asp-c:${meta.color}">
          <span class="asp-ic">${meta.icon}</span>
          <div class="asp-name">${name}</div>
          <div class="mini-bars">
            <div class="mb-row"><span class="mb-lbl" style="color:${C.green}">POS</span><div class="mb-track"><div class="mb-fill fill-g" style="width:${pp}%"></div></div><span class="mb-pct">${pp}%</span></div>
            <div class="mb-row"><span class="mb-lbl" style="color:${C.grey}">NEU</span><div class="mb-track"><div class="mb-fill fill-gr" style="width:${ep}%"></div></div><span class="mb-pct">${ep}%</span></div>
            <div class="mb-row"><span class="mb-lbl" style="color:${C.red}">NEG</span><div class="mb-track"><div class="mb-fill fill-r" style="width:${np}%"></div></div><span class="mb-pct">${np}%</span></div>
          </div>
          <div class="asp-pmi">PMI: <span style="color:${pc}">${pol>=0?'+':''}${pol.toFixed(4)}</span> · n=${v.total}</div>
        </div>`;
    }).join('');
  }

  // Twitter grouped bar
  const twEl = document.getElementById('absa-tw-chart');
  if (twEl) {
    const asps = Object.keys(absa.twitter).filter(a=>a!=='Other');
    new Chart(twEl, {
      type:'bar',
      data:{labels:asps, datasets:[
        {label:'Positive', data:asps.map(a=>absa.twitter[a]?.positive||0), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:4},
        {label:'Neutral',  data:asps.map(a=>absa.twitter[a]?.neutral||0),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1, borderRadius:4},
        {label:'Negative', data:asps.map(a=>absa.twitter[a]?.negative||0), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1, borderRadius:4},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}}},
      },
    });
  }

  // YouTube horizontal
  const ytEl = document.getElementById('absa-yt-chart');
  if (ytEl) {
    const asps = Object.keys(absa.youtube).filter(a=>a!=='Other');
    new Chart(ytEl, {
      type:'bar', indexAxis:'y',
      data:{labels:asps, datasets:[
        {label:'Positive', data:asps.map(a=>absa.youtube[a]?.positive||0), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:4},
        {label:'Negative', data:asps.map(a=>absa.youtube[a]?.negative||0), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1, borderRadius:4},
        {label:'Neutral',  data:asps.map(a=>absa.youtube[a]?.neutral||0),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1, borderRadius:4},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}}},
      },
    });
  }
}

// ── Emotion section ─────────────────────────────────────────────────────────
function buildEmotions(emoData) {
  // Bar list
  const listEl = document.getElementById('emo-bar-list');
  if (listEl) {
    const maxV = Math.max(...Object.values(emoData.distribution));
    listEl.innerHTML = Object.entries(emoData.distribution)
      .sort((a,b)=>b[1]-a[1])
      .map(([name,cnt])=>{
        const meta = EMO_META[name]||{emoji:'•',color:C.grey};
        const pct  = Math.round(cnt/maxV*100);
        return `
          <div class="emo-row">
            <span class="emo-emoji">${meta.emoji}</span>
            <span class="emo-lbl">${name}</span>
            <div class="emo-track"><div class="emo-fill" style="width:${pct}%;background:${meta.color}"></div></div>
            <span class="emo-cnt">${cnt}</span>
          </div>`;
      }).join('');
  }

  // Radar
  const radarEl = document.getElementById('emo-radar-chart');
  if (radarEl) {
    const keys = Object.keys(emoData.distribution);
    new Chart(radarEl, {
      type:'radar',
      data:{labels:keys, datasets:[{label:'Count', data:Object.values(emoData.distribution),
        backgroundColor:rgba(C.purple,.12), borderColor:C.purple,
        pointBackgroundColor:C.purple, pointRadius:4, borderWidth:2}]},
      options:{responsive:true, maintainAspectRatio:false,
        plugins:{legend:{display:false}},
        scales:{r:{ticks:{backdropColor:'transparent',stepSize:40}, pointLabels:{font:{size:11}}}},
      },
    });
  }

  // Heatmap (stacked bar)
  const hmEl = document.getElementById('asp-emo-heatmap');
  if (hmEl && emoData.heatmap) {
    const asps = Object.keys(emoData.heatmap);
    const emos = ['Fear','Anger','Hope','Trust','Sadness','Anticipation','Surprise','Disgust'];
    const clrs = [C.purple,C.red,C.green,C.teal,'#3b82f6',C.orange,'#f59e0b','#854d0e'];
    new Chart(hmEl, {
      type:'bar',
      data:{labels:asps, datasets:emos.map((e,i)=>({
        label:e, data:asps.map(a=>emoData.heatmap[a]?.[e]||0),
        backgroundColor:rgba(clrs[i],.75), borderColor:clrs[i], borderWidth:1,
      }))},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{stacked:true, grid:{color:C.border}}, y:{stacked:true, grid:{color:C.border}}},
        plugins:{legend:{labels:{font:{size:10}}}},
      },
    });
  }
}

// ── Trends section ──────────────────────────────────────────────────────────
function buildTrends(trends) {
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const tVals  = months.map((_,i)=>trends[String(i+1)]?.avg_polarity??0);

  const lEl = document.getElementById('trend-line-chart');
  if (lEl) {
    new Chart(lEl, {
      type:'line',
      data:{labels:months, datasets:[
        {label:'PMI Polarity', data:tVals, borderColor:C.blue, backgroundColor:rgba(C.blue,.07),
          fill:true, tension:.4, pointBackgroundColor:tVals.map(v=>v>=0?C.green:C.red),
          pointRadius:5, pointHoverRadius:8, borderWidth:2.5},
        {label:'Baseline (0)', data:months.map(()=>0), borderColor:rgba(C.grey,.4),
          borderDash:[5,5], borderWidth:1, pointRadius:0, fill:false},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}, ticks:{callback:v=>v.toFixed(3)}}},
        plugins:{
          legend:{labels:{font:{size:11}}},
          tooltip:{callbacks:{label:ctx=>`PMI: ${ctx.parsed.y.toFixed(4)}`}},
        },
      },
    });
  }

  const vEl = document.getElementById('trend-vol-chart');
  if (vEl) {
    new Chart(vEl, {
      type:'bar',
      data:{labels:months, datasets:[
        {label:'Positive', data:months.map((_,i)=>trends[String(i+1)]?.positive||0), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:3},
        {label:'Neutral',  data:months.map((_,i)=>trends[String(i+1)]?.neutral||0),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1},
        {label:'Negative', data:months.map((_,i)=>trends[String(i+1)]?.negative||0), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{stacked:true, grid:{color:C.border}}, y:{stacked:true, grid:{color:C.border}}},
        plugins:{legend:{labels:{font:{size:10}}}},
      },
    });
  }

  const ytEl = document.getElementById('yt-trend-chart');
  if (ytEl) {
    new Chart(ytEl, {
      type:'line',
      data:{
        labels:['2014','2015','2016','2017','2018','2019','2020','2021','2022','2023'],
        datasets:[{label:'YouTube Comments', data:[1,5,26,38,36,201,129,269,1036,1015],
          borderColor:C.red, backgroundColor:rgba(C.red,.07), fill:true, tension:.4, pointRadius:4, borderWidth:2}],
      },
      options:{responsive:true, maintainAspectRatio:false,
        plugins:{legend:{display:false}},
        scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}}},
      },
    });
  }
}

// ── Platform section ────────────────────────────────────────────────────────
function buildPlatforms(platform) {
  const PLAT_META = {
    Twitter:   {icon:'🐦', color:'#1da1f2', note:'Best for crisis communication, urgent policy advocacy. Negativity bias driven by climate urgency discourse.'},
    YouTube:   {icon:'▶',  color:'#ff0000', note:'Highest positivity (62.1%). Optimal for educational content, solution-focused documentaries, awareness campaigns.'},
    Instagram: {icon:'📸', color:'#c13584', note:'Engagement-driven, neutral tone. 18.1% of impressions from hashtags — ideal for sustainability branding and visual storytelling.'},
  };
  const container = document.getElementById('plat-cards');
  if (container) {
    container.innerHTML = Object.entries(platform).map(([name,stat])=>{
      const meta = PLAT_META[name]||{icon:'📱',color:C.blue,note:''};
      return `
        <div class="plat-card" style="--plat-c:${meta.color}">
          <div class="plat-icon">${meta.icon}</div>
          <div class="plat-name">${name}</div>
          <div class="plat-bars">
            <div class="plat-bar-row"><span class="plat-bar-lbl" style="color:${C.green}">POS</span><div class="plat-bar-track"><div class="plat-bar-fill fill-g" style="width:${stat.pos_pct}%"></div></div><span class="plat-bar-pct">${stat.pos_pct}%</span></div>
            <div class="plat-bar-row"><span class="plat-bar-lbl" style="color:${C.grey}">NEU</span><div class="plat-bar-track"><div class="plat-bar-fill fill-gr" style="width:${stat.neu_pct}%"></div></div><span class="plat-bar-pct">${stat.neu_pct}%</span></div>
            <div class="plat-bar-row"><span class="plat-bar-lbl" style="color:${C.red}">NEG</span><div class="plat-bar-track"><div class="plat-bar-fill fill-r" style="width:${stat.neg_pct}%"></div></div><span class="plat-bar-pct">${stat.neg_pct}%</span></div>
          </div>
          <div class="plat-note">${meta.note}</div>
        </div>`;
    }).join('');
  }

  const pctEl = document.getElementById('plat-pct-chart');
  if (pctEl) {
    const labels = Object.keys(platform);
    new Chart(pctEl, {
      type:'bar',
      data:{labels, datasets:[
        {label:'Positive %', data:labels.map(p=>platform[p].pos_pct), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:4},
        {label:'Neutral %',  data:labels.map(p=>platform[p].neu_pct), backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1},
        {label:'Negative %', data:labels.map(p=>platform[p].neg_pct), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{stacked:true, grid:{color:C.border}}, y:{stacked:true, max:100, ticks:{callback:v=>v+'%'}, grid:{color:C.border}}},
      },
    });
  }

  const absEl = document.getElementById('plat-abs-chart');
  if (absEl) {
    const labels = Object.keys(platform);
    new Chart(absEl, {
      type:'bar',
      data:{labels, datasets:[
        {label:'Positive', data:labels.map(p=>platform[p].positive), backgroundColor:rgba(C.green,.75), borderColor:C.green, borderWidth:1, borderRadius:5},
        {label:'Neutral',  data:labels.map(p=>platform[p].neutral),  backgroundColor:rgba(C.grey,.5),  borderColor:C.grey,  borderWidth:1, borderRadius:5},
        {label:'Negative', data:labels.map(p=>platform[p].negative), backgroundColor:rgba(C.red,.75),  borderColor:C.red,   borderWidth:1, borderRadius:5},
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:{color:C.border}}, y:{grid:{color:C.border}}},
      },
    });
  }
}

// ── Recommendations ─────────────────────────────────────────────────────────
function buildRecs(recs) {
  const el = document.getElementById('rec-list');
  if (!el) return;
  el.innerHTML = recs.map(r=>`
    <div class="rec-card" style="--rc:${r.color}">
      <div class="rec-type">${r.type.toUpperCase()}</div>
      <div class="rec-title">${r.title}</div>
      <div class="rec-desc">${r.desc}</div>
      <span class="rec-plat">${r.platform}</span>
    </div>`).join('');
}

// ── Master init ─────────────────────────────────────────────────────────────
async function init() {
  const overlay = document.getElementById('loadingOverlay');
  try {
    const [ov, plat, absa, emo, trends, recs] = await Promise.all([
      fetchJSON('/api/overview',        SAMPLE.overview),
      fetchJSON('/api/platform',        SAMPLE.platform),
      fetchJSON('/api/absa',            SAMPLE.absa),
      fetchJSON('/api/emotions',        SAMPLE.emotions),
      fetchJSON('/api/trends',          SAMPLE.trends),
      fetchJSON('/api/recommendations', SAMPLE.recs),
    ]);

    buildKPIGrid(ov);
    buildOverviewPlatform(plat);
    buildOverviewRadar(emo.distribution);
    buildABSA(absa);
    buildEmotions(emo);
    buildTrends(trends);
    buildPlatforms(plat);
    buildRecs(recs);

  } catch (err) {
    console.error('Init error:', err);
  } finally {
    if (overlay) overlay.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', init);
